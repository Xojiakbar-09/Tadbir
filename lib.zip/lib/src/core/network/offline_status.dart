import 'package:dio/dio.dart';
import 'package:flutter/foundation.dart';

/// Internet holatini oxirgi Strapi so'rovining natijasi bo'yicha kuzatamiz.
/// Aloqa uzilganda eski cache ishlatilsa ham foydalanuvchi xabardor bo'ladi.
class OfflineStatus {
  OfflineStatus._();

  static final ValueNotifier<bool> offline = ValueNotifier<bool>(false);

  static bool isConnectionFailure(Object error) {
    if (error is! DioException) return false;
    return switch (error.type) {
      DioExceptionType.connectionError ||
      DioExceptionType.connectionTimeout ||
      DioExceptionType.receiveTimeout ||
      DioExceptionType.sendTimeout => true,
      _ => false,
    };
  }

  static void online() => offline.value = false;
  static void connectionFailed() => offline.value = true;
}
